/**
 * Thrown when trying to dequeue an item from an empty queue.
 */
@SuppressWarnings("serial")
public class EmptyQueueException extends Exception {}
