/**
 * Thrown when trying to push an item onto a full stack.
 */
@SuppressWarnings("serial")
public class FullStackException extends Exception {}
