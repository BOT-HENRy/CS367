/**
 * Thrown when trying to add a train to a full platform.
 */
@SuppressWarnings("serial")
public class FullPlatformException extends Exception {}
