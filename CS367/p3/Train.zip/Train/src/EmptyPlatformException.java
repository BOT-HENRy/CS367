/**
 * Thrown when trying to remove a train from an empty platform.
 */
@SuppressWarnings("serial")
public class EmptyPlatformException extends Exception {}
