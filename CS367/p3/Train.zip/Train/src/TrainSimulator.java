import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class TrainSimulator {

	public static void main(String args[]){
		
		Scanner stdin = new Scanner(System.in);		
		
		String Stations_File_Name = "stations2.txt";
		String Trains_File_Name = "trains2.txt";
		Station[] stations = null;
		Train[] trains = null;
		int numS = 0;
		int numT = 0;
		
		//Import files
		File srcFile = new File(Stations_File_Name);
		try {
			Scanner fileIn = new Scanner(srcFile);
			String currline = fileIn.nextLine();
			numS = Integer.parseInt(currline);
			stations =  new Station[numS];
			
			for (int i = 0; i < numS; i ++)
			{
				currline = fileIn.nextLine();
				int lineLength = currline.length();
				int id = 0;
				int capacity = 0;
				for(int k = 0; k < lineLength; k++)
				{
					if(currline.charAt(k) == ',')
					{
						id = Integer.parseInt(currline.substring(0, k));
						capacity = Integer.parseInt(currline.substring(k+1, lineLength));
						stations[i] = new Station(id, capacity);
						continue;
					}
				}				
			}
		} catch (FileNotFoundException e) {
			
		}	
				
		srcFile = new File(Trains_File_Name);
		try {
			Scanner fileIn = new Scanner(srcFile);
			String currline = fileIn.nextLine();
			numT = Integer.parseInt(currline);
			trains =  new Train[numT];
			
			for (int i = 0; i < numT; i ++)
			{
				currline = fileIn.nextLine();
				int lineLength = currline.length();
				int index = 0;
				int id = 0;
				for(int k = 0; k < lineLength; k++)
				{
					if(currline.charAt(k) == ',' && index ==0)
					{
						id = Integer.parseInt(currline.substring(0, k));
						trains[i] = new Train(id);						
						index = k + 1;
						continue; 
					}
					if(currline.charAt(k) == ',' && index != 0)
					{
						int ETD = Integer.parseInt(currline.substring(index, k));
						trains[i].getETD().add(ETD);
						index = k + 1;
						continue;
					}
					if(k == lineLength-1 && index != 0)
					{
						int ETD = Integer.parseInt(currline.substring(index, k+1));
						trains[i].getETD().add(ETD);
						continue;
					}
				}				
			}
		} catch (FileNotFoundException e) {
			System.out.println("File not Found!");
		}
		
		//create stations
		for(int i = trains.length - 1; i >= 0; i --)
		{
			try {
				stations[0].getPlatform().put(trains[i]);
			} catch (FullPlatformException e) {
				
			}
		}
		
		int time = 0;
		SimpleQueue<Train> trainMid = new SimpleQueue<Train>(numT);
		
		//���壡����
		//Ӧ��ͬʱ�������stations,��ʱ�䣬�����һ��station��ǰ�������޿ɼ��복��������ATD,ATA����Ϊÿ��ֻ�ܶ�������ĳ�
		while(!stations[numS-1].getPlatform().isFull())
		{
			
			for(int i = numS - 1; i > 0; i--)
			{
				//��������
				if(!stations[i].getPlatform().isFull() && !stations[i - 1].getPlatform().isEmpty())
				{
					
					if(stations[i - 1].getPlatform().check().getATA().size() >= 1)
					{
						if(stations[i - 1].getPlatform().check().getATA().get(i - 2) == time)
						{
							continue;
						}
						while(!stations[i - 1].getPlatform().isEmpty() && time >= stations[i - 1].getPlatform().check().getETD().get(i - 1) && stations[i - 1].getPlatform().check().getATA().get(i-2) <= time)
						{
							stations[i - 1].getPlatform().check().getATD().add(time);
							
							System.out.println(stations[i - 1].getPlatform().check().getId()+"leave" + time+"��������");
						
							try {
								
								stations[i].getPlatform().put(stations[i - 1].getPlatform().get());
								stations[i].getPlatform().check().getATA().add(time + 10);
								System.out.println(stations[i].getPlatform().check().getId()+"arrive" + (time+10)+"��������");
							} catch (FullPlatformException e) {
								
							}
						}
					}else
					{
						while(!stations[i - 1].getPlatform().isEmpty() && time >= stations[i - 1].getPlatform().check().getETD().get(i - 1))
						{
							stations[i - 1].getPlatform().check().getATD().add(time);
							
							System.out.println(stations[i - 1].getPlatform().check().getId()+"leave" + time+"��������");
						
							try {
								
								stations[i].getPlatform().put(stations[i - 1].getPlatform().get());
								stations[i].getPlatform().check().getATA().add(time + 10);
								System.out.println(stations[i].getPlatform().check().getId()+"arrive" + (time+10)+"��������");
							} catch (FullPlatformException e) {
								
							}
						}
					}
							
				}
				//��վleave station���Ⱥ�
				while(!stations[i - 1].getPlatform().isEmpty() && stations[i].getPlatform().isFull () && stations[i - 1].getPlatform().check().getETD().get(i-1) <= time )
				{
					stations[i - 1].getPlatform().check().getATD().add(time);
					
					System.out.println(stations[i - 1].getPlatform().check().getId()+"leave"+time+"��վ���Ⱥ�");
					try {
						trainMid.enqueue(stations[i - 1].getPlatform().get());
					} catch (FullQueueException e) {
						
					}
				}
				
				//�Ⱥ򲢽�վ
				try {
					if(!trainMid.isEmpty() && i == trainMid.peek().getATD().size() && !stations[i].getPlatform().isFull())
					{
						while(!stations[i].getPlatform().isFull() && !trainMid.isEmpty() && i == trainMid.peek().getATD().size())
						{
							
							try {
								trainMid.peek().getATA().add(time);
								
								stations[i].getPlatform().put(trainMid.dequeue());
								
								System.out.println(stations[i].getPlatform().check().getId()+"arrive" + time+"�Ⱥ򲢽�վ");
							} catch (FullPlatformException e) {
								
							} catch (EmptyQueueException e) {
								
							}
							
						}
					
					}
				} catch (EmptyQueueException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				if(stations[numS-1].getPlatform().isFull())
				{
					break;
				}
			
			}
			time ++;
			
		}
		
		Train[] train = new Train[numT];
		int timeTotal = stations[numS-1].getPlatform().check().getATA().get(stations[numS-1].getPlatform().check().getATA().size()-1);
		
		System.out.println("");
		System.out.println("������������");
		//function 0 
		for(int i = 0; i < numT; i ++)
		{
			int pos = stations[numS - 1].getPlatform().check().getId();
			train[pos - 1] = stations[numS - 1].getPlatform().get();
		}
		for(int i = 0; i <= timeTotal; i++)
		{
			for(int j = 0; j < numT; j ++)
			{
				for(int k = 0; k <= train[j].getATD().size() - 1; k ++)
				{
					if(train[j].getATD().get(k) == i)
					{
						System.out.println(i + ":	Train "+train[j].getId()+" has exited from station " + (k + 1) + ".");
					}
				}
				for(int k = 0; k <= train[j].getATA().size() - 1; k ++)
				{
					if(train[j].getATA().get(k) == i)
					{
						System.out.println(i + ":	Train "+train[j].getId()+" has been parked at station " + (k + 2) + ".");
					}
				}
				
				
				
			}
			
		}
		
		//function 1 
		System.out.println("");
		for(int j = 0; j < numT; j ++)
		{
			System.out.print("[");
			
			for(int k = 0; k < train[j].getATD().size() - 1; k ++)
			{
				System.out.print(train[j].getATD().get(k) + ", " );
			}
			System.out.print(train[j].getATD().get(train[j].getATD().size() - 1) + "]" );
			System.out.println("");
		}
		
		//function 2
		System.out.println("");
		for(int j = 0; j < numT; j ++)
		{
			System.out.print("[");
			
			for(int k = 0; k < train[j].getATA().size() - 1; k ++)
			{
				System.out.print(train[j].getATA().get(k) + ", " );
			}
			System.out.print(train[j].getATA().get(train[j].getATA().size() - 1) + "]" );
			System.out.println("");
		}
}
}
