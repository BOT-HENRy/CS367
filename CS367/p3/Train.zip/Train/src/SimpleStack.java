
public class SimpleStack<E> implements StackADT<E> {
	private int capacity;  // initial array size
    private E[] items; // the items in the stack
    private int numItems;   // the number of items in the stack

    public SimpleStack(int capacity) {
    	this.capacity = capacity;
    	items = (E[])(new Object[this.capacity]);
        numItems = 0;
    }
    
    public void push(E ob) throws FullStackException {
    	if (items.length == numItems)
    	{
    		throw new FullStackException();
    	}
    	else
    	{
    		items[numItems] = ob;
    	    numItems++;
    	}
    }

    public E pop() throws EmptyStackException {
    	if (numItems == 0) 
    	{
            throw new EmptyStackException();
        }
        else 
        {
            numItems--;
            return items[numItems];
        }
    }
  
    public E peek() throws EmptyStackException {
    	if (numItems == 0) 
    	{
            throw new EmptyStackException();
        }
        else 
        {
            return items[numItems - 1];
        }
    }
    
    public boolean isEmpty() {
    	if (numItems == 0) 
    	{
            return true;
        }
    	return false;
    }
    
    public boolean isFull() {
    	if (numItems == capacity) 
    	{
            return true;
        }
    	return false;
    }
}
