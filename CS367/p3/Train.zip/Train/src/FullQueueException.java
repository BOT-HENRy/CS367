/**
 * Thrown when trying to enqueue an item into a full queue.
 */
@SuppressWarnings("serial")
public class FullQueueException extends Exception {}
