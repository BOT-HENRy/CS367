
public class SimpleQueue<E> implements QueueADT<E> {
	private int capacity;  // initial array size
    private E[] items; // the items in the queue
    private int numItems;   // the number of items in the queue


    public SimpleQueue(int capacity) {
    	this.capacity = capacity;
    	items = (E[])(new Object[this.capacity]);
        numItems = 0;
    }
        
    public void enqueue(E ob) throws FullQueueException {
    	if (items.length == numItems) 
    	{
    		throw new FullQueueException();
    	}
    	else
    	{
    		items[numItems] = ob;
    	    numItems ++;
    	}
    }

    public E dequeue() throws EmptyQueueException {
    	if (items.length == 0) 
    	{
    		throw new EmptyQueueException();
    	}
    	else
    	{
    		E head = items[0];
    		for(int i = 0; i < numItems - 1; i ++)
    		{
    			items[i] = items[i + 1];
    		}
    	    numItems --;
    	    return head;
    	}
    }
    
    public E peek() throws EmptyQueueException{
    	if (items.length == 0) 
    	{
    		throw new EmptyQueueException();
    	}
    	else
    	{
    		return items[0];
    	}
    }

    public boolean isEmpty() {
    	if (numItems == 0) 
    	{
            return true;
        }
    	return false;
    }
    
    public boolean isFull() {
    	if (numItems == capacity) 
    	{
            return true;
        }
    	return false;
    }
}
