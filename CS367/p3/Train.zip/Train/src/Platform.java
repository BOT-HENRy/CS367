
public class Platform implements PlatformADT{
	private SimpleStack<Train> platForm;
	
	public Platform(int capacity){
		
		platForm = new SimpleStack<Train>(capacity);
		
	}
	
	public void put(Train item) throws FullPlatformException {
		if (platForm.isFull())
		{
			throw new FullPlatformException();
		}
		else
		{
			try{
				platForm.push(item);
			}catch(FullStackException ex){
				System.out.println("The Stack is full");
			}			
		}
	}
	
	public Train get(){
		Train topTrain = null;
		try{
			topTrain = platForm.pop();
		}catch(EmptyStackException ex){
			System.out.println("The Stack is empty");
		}
		return topTrain;
	}
	
	public Train check(){
		Train topTrain = null;
		try{
			topTrain = platForm.peek();
		}catch(EmptyStackException ex){
			System.out.println("The Stack is empty");
		}
		return topTrain;
	}
	
	public boolean isEmpty(){
		return platForm.isEmpty();
	}
	
	public boolean isFull(){
		return platForm.isFull();
	}
	
}
