/**
 * Thrown when trying to pop an item from an empty stack.
 */
@SuppressWarnings("serial")
public class EmptyStackException extends Exception {}
